# DeltaLootAssistant｜物资筛选助手（Android 原型）

面向 Redmi K 系列 / 6GB RAM 的本地离线截图分析工具。最低 Android 版本为 Android 8.0（API 26）。不需要 Root、账号登录或网络 API。

## 本次增量（0.2.0）
- 使用 Android SQLiteOpenHelper 建立本地数据库 `delta_loot.db`。
- `loot_items` 物资目录包含：规范名称、别名、参考价格、重量、稀有度、来源、更新时间、人工确认状态、自定义保留标记。
- `scan_history` 保存每条人工复核记录：时间、OCR 原文、修正名称、匹配物资、价格、人工决策及是否修正。
- 可在应用内新增/更新物资目录条目，录入别名、参考价、重量、稀有度、来源，并加入自定义保留名单。
- OCR 名称匹配支持规范化（全半角、空格、大小写及常见分隔符处理）和别名匹配；多个匹配时优先最长别名。
- 价格只从“价格、单价、价值、售价、估价”标签后提取。普通数字不作为价格，避免把数量、编号、等级误判成价格。
- 未知名称、目录未确认、缺少明确价格等情况进入待确认；目录参考价只作为参考，不直接触发出售判定。
- 每条识别结果可人工修正名称、选择保留/出售候选/待确认并保存历史。出售候选仅供人工查看，不执行游戏内交易。
- 背包容量可手动设置；已匹配条目的重量和价格可汇总展示。重量汇总不等同于自动装包规划。

## 数据维护原则
本项目不内置未经核验的游戏物资价格。请从你认可的游戏内资料或自行核验的数据录入“来源/备注”和参考价。价格会变化，更新目录时请同步修改来源说明。`manually_confirmed` 表示目录条目已由用户核验；OCR 识别本身仍需逐条确认。

## 本地构建步骤
1. 在电脑安装 Android Studio 稳定版，并安装 Android SDK Platform 35、Android SDK Build-Tools。
2. 解压项目 ZIP，在 Android Studio 中选择 **Open**，打开 `DeltaLootAssistant` 项目根目录（不是 `app` 子目录）。
3. 等待 Gradle Sync 完成。首次同步需要网络下载 Android Gradle Plugin、Kotlin、Compose 和 ML Kit 依赖；安装后的图片文字识别在设备本地执行。
4. 使用 JDK 17（Android Studio 内置 JBR 通常可用）。
5. 运行单元测试：在项目根目录执行 `gradle :app:testDebugUnitTest`；若本机没有 Gradle 命令，可在 Android Studio 的 Gradle 工具窗口运行 `app > Tasks > verification > testDebugUnitTest`。
6. 构建 APK：Android Studio 选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
7. Debug APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。安装前确认设备 Android 版本为 8.0 或更高。

## 当前限制与待完成
- 本次没有在当前环境完成 Android Gradle 编译或真机安装验证；交付的是更新源码，不是已验证 APK。
- 目录编辑目前支持新增/同名更新；尚未提供目录删除、批量 CSV 导入导出和逐条历史记录浏览页面。
- OCR 目前按文本行匹配，尚未利用屏幕区域/表格布局定位物资名称与价格列。复杂排版、低清截图仍需人工核对。
- 价格解析只识别明确标签后的数字；游戏截图若只显示裸数字，将安全地留待人工确认。
- 背包重量与价值当前为已匹配识别条目的汇总，不会自动推断物品数量或规划丢弃顺序。

## 合规边界
应用只处理用户主动导入的截图和本地录入的数据；不读取/注入游戏进程、不模拟触控、不执行无人值守跑图/刷取/交易，也不包含反作弊规避逻辑。


## 手机端云端构建 APK（无需电脑）

项目已附带 GitHub Actions 云端构建工作流：`.github/workflows/android-apk.yml`。
它会在云端安装 JDK 17、Android SDK 35 和 Gradle 8.9，先运行单元测试，再构建 Debug APK，并将 APK 作为构建产物保存 14 天。

**注意：** 云端构建需要 GitHub 账号，并且需要把项目源码放进一个 GitHub 仓库。此步骤可尝试在手机浏览器中开启“请求桌面网站”完成；GitHub 页面布局可能随版本变化。

1. 在手机浏览器登录 GitHub，创建一个新的空仓库（建议设为 Private）。
2. 将本 ZIP 解压到手机“文件”应用中。
3. 在仓库页面选择添加/上传文件，将项目根目录 `DeltaLootAssistant` 内的文件和 `.github` 文件夹上传到仓库根目录；确保 `settings.gradle.kts`、`build.gradle.kts`、`app/` 和 `.github/` 位于仓库根目录，而不是再套一层目录。
4. 打开仓库的 **Actions** 页面，选择 **Build Android APK**，点击 **Run workflow**。
5. 等待工作流结束。成功后进入该次运行页面，在 **Artifacts** 区域下载 `DeltaLootAssistant-debug-apk`，解压后得到 `app-debug.apk`。
6. 在 Redmi 手机上打开 APK 安装。若系统提示，允许该来源安装应用。

如果上传界面无法从 iPhone 选择整个目录，可先在 GitHub 网页尝试逐批上传文件；不要只上传 ZIP 文件本身，因为工作流需要仓库根目录中存在 Gradle 项目文件。

**构建边界：** 该工作流构建的是 Debug APK，未签名为可发布版本。首次构建还需云端下载依赖；构建成功与否以 GitHub Actions 日志为准。
