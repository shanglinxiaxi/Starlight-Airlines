package com.example.deltalootassistant

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import kotlinx.coroutines.launch
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { LootAssistantScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LootAssistantScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val database = remember { LootDatabase(context.applicationContext) }
    var catalog by remember { mutableStateOf(database.allItems()) }
    var threshold by remember { mutableIntStateOf(50000) }
    var capacity by remember { mutableIntStateOf(20) }
    var usedWeight by remember { mutableIntStateOf(0) }
    var ocrText by remember { mutableStateOf("尚未导入截图") }
    var detections by remember { mutableStateOf(listOf<LootDetection>()) }
    var status by remember { mutableStateOf("等待导入物资截图") }
    var busy by remember { mutableStateOf(false) }
    var historyCount by remember { mutableIntStateOf(database.historyCount()) }
    var itemName by remember { mutableStateOf("") }
    var aliases by remember { mutableStateOf("") }
    var itemPrice by remember { mutableStateOf("") }
    var itemWeight by remember { mutableStateOf("") }
    var rarity by remember { mutableStateOf("未设置") }
    var source by remember { mutableStateOf("用户录入") }
    var keepAlways by remember { mutableStateOf(false) }

    fun refreshCatalog() { catalog = database.allItems() }
    fun rerunMatches(text: String) { detections = text.lines().filter { it.isNotBlank() }.map { ClassificationEngine.classify(it, catalog, threshold) } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true; status = "正在本地识别图片…"
            try {
                val bitmap = loadBitmap(context, uri)
                ocrText = recognizeChinese(bitmap)
                rerunMatches(ocrText)
                status = "识别完成：名称匹配与价格字段均需人工核对"
            } catch (e: Exception) {
                status = "识别失败：${e.localizedMessage ?: "请换一张清晰截图"}"
            } finally { busy = false }
        }
    }

    LaunchedEffect(threshold, catalog, ocrText) {
        if (ocrText != "尚未导入截图") rerunMatches(ocrText)
    }

    Scaffold(topBar = { TopAppBar(title = { Text("物资筛选助手") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("离线截图分析 · 本地 SQLite", style = MaterialTheme.typography.titleMedium)
                        Text("只分析主动导入的图片；不连接或控制游戏客户端，不自动出售。")
                        Button(onClick = { picker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                            Text(if (busy) "识别中…" else "导入物资截图")
                        }
                        Text(status, style = MaterialTheme.typography.bodySmall)
                        Text("本地历史记录：$historyCount 条", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("筛选与背包", style = MaterialTheme.typography.titleMedium)
                    Text("保留参考阈值：$threshold 游戏币")
                    Slider(value = threshold.toFloat(), onValueChange = { threshold = it.toInt() }, valueRange = 10000f..200000f, steps = 37)
                    Text("背包容量：$capacity kg")
                    Slider(value = capacity.toFloat(), onValueChange = { capacity = it.toInt(); usedWeight = usedWeight.coerceAtMost(capacity) }, valueRange = 5f..50f, steps = 44)
                    Text("已用重量：$usedWeight kg")
                    Slider(value = usedWeight.toFloat().coerceIn(0f, capacity.toFloat()), onValueChange = { usedWeight = it.toInt() }, valueRange = 0f..capacity.toFloat(), steps = (capacity - 1).coerceAtLeast(0))
                    Text("剩余容量：${(capacity-usedWeight).coerceAtLeast(0)} kg")
                    val matchedWeight = detections.mapNotNull { it.matchedItem?.weight }.sum()
                    val matchedValue = detections.mapNotNull { it.detectedPrice }.sum()
                    Text("本次已匹配重量合计：${"%.2f".format(matchedWeight)} kg · 识别价格合计：$matchedValue（仅供核对）")
                } }
            }
            item {
                Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("物资目录维护", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(itemName, { itemName=it }, label={Text("规范名称（必填）")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    OutlinedTextField(aliases, { aliases=it }, label={Text("别名（用逗号分隔）")}, modifier=Modifier.fillMaxWidth())
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(itemPrice, { itemPrice=it.filter(Char::isDigit) }, label={Text("参考价格")}, modifier=Modifier.weight(1f), singleLine=true)
                        OutlinedTextField(itemWeight, { itemWeight=it.filter { ch -> ch.isDigit() || ch=='.' } }, label={Text("重量 kg")}, modifier=Modifier.weight(1f), singleLine=true)
                    }
                    OutlinedTextField(rarity, { rarity=it }, label={Text("稀有度")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    OutlinedTextField(source, { source=it }, label={Text("数据来源/备注")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    Row { Checkbox(checked=keepAlways, onCheckedChange={keepAlways=it}); Text("加入自定义高价值保留名单", modifier=Modifier.padding(top=12.dp)) }
                    Button(onClick={
                        if (itemName.isNotBlank()) {
                            database.upsert(LootItem(canonicalName=itemName.trim(), aliases=aliases.split(',', '，').map{it.trim()}.filter{it.isNotBlank()}, referencePrice=itemPrice.toIntOrNull(), weight=itemWeight.toDoubleOrNull(), rarity=rarity.ifBlank{"未设置"}, source=source.ifBlank{"用户录入"}, manuallyConfirmed=true, keepAlways=keepAlways))
                            itemName=""; aliases=""; itemPrice=""; itemWeight=""; rarity="未设置"; source="用户录入"; keepAlways=false
                            refreshCatalog(); status="目录已保存到本机"
                        }
                    }, enabled=itemName.isNotBlank(), modifier=Modifier.fillMaxWidth()) { Text("保存/更新目录物资") }
                    Text("目录条目：${catalog.size} 条。价格、重量与稀有度需由你按可靠来源维护。", style=MaterialTheme.typography.bodySmall)
                } }
            }
            item { Text("识别结果 · 逐项复核", style=MaterialTheme.typography.titleMedium) }
            if (detections.isEmpty()) item { Text("导入截图后显示匹配结果。未知项不会被自动判定为出售。") }
            items(detections) { detection ->
                var correctedName by remember(detection.rawLine) { mutableStateOf(detection.matchedItem?.canonicalName ?: "") }
                var manualDecision by remember(detection.rawLine) { mutableStateOf(detection.decision) }
                Card { Column(Modifier.padding(12.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("OCR：${detection.rawLine}", style=MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(correctedName, { correctedName=it }, label={Text("人工修正规范名称")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                    Text("匹配：${detection.matchedItem?.canonicalName ?: "未匹配"} · 价格：${detection.detectedPrice?.toString() ?: "未识别"}")
                    Text("判定：$manualDecision", style=MaterialTheme.typography.bodyMedium)
                    Text(detection.confidenceNote, style=MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick={manualDecision="人工确认保留"}) { Text("确认保留") }
                        TextButton(onClick={manualDecision="出售候选（人工复核）"}) { Text("列为出售候选") }
                        TextButton(onClick={manualDecision="未知项 · 待确认"}) { Text("待确认") }
                    }
                    Button(onClick={
                        val corrected = catalog.firstOrNull { ClassificationEngine.normalize(it.canonicalName)==ClassificationEngine.normalize(correctedName) || it.aliases.any { a -> ClassificationEngine.normalize(a)==ClassificationEngine.normalize(correctedName) } }
                        database.saveHistory(detection.rawLine, correctedName.ifBlank { detection.rawLine }, corrected?.id ?: detection.matchedItem?.id, detection.detectedPrice, manualDecision, correctedName != (detection.matchedItem?.canonicalName ?: "") || manualDecision != detection.decision)
                        historyCount=database.historyCount(); status="已保存人工复核记录"
                    }, modifier=Modifier.fillMaxWidth()) { Text("保存本条复核记录") }
                } }
            }
            item {
                Card { Column(Modifier.padding(12.dp)) {
                    Text("本地目录概览", style=MaterialTheme.typography.titleSmall)
                    catalog.take(30).forEach { item ->
                        Text("${item.canonicalName}｜参考价：${item.referencePrice ?: "未录入"}｜重量：${item.weight ?: "未录入"} kg｜${if(item.keepAlways) "自定义保留" else item.rarity}", style=MaterialTheme.typography.bodySmall)
                    }
                    if (catalog.isEmpty()) Text("目录目前为空，请先录入你确认过的物资名称、别名和数据。")
                } }
            }
            item {
                Text("判定原则：普通数字（数量、编号、等级等）不会被当作价格；只有数字紧跟‘价格/单价/价值/售价/估价’标签时才作为截图价格。未匹配名称、未确认目录项或缺少价格的条目进入待确认。出售候选仅记录，不执行游戏内交易。", style=MaterialTheme.typography.bodySmall)
            }
            item { Text("原始 OCR 文本\n$ocrText", style=MaterialTheme.typography.bodySmall) }
        }
    }
}

private fun loadBitmap(context: android.content.Context, uri: Uri): Bitmap =
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) ?: throw IllegalArgumentException("无法读取图片") }
        ?: throw IllegalArgumentException("无法打开图片")

private suspend fun recognizeChinese(bitmap: Bitmap): String = suspendCancellableCoroutine { continuation ->
    val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
    recognizer.process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { result -> if (continuation.isActive) continuation.resume(result.text); recognizer.close() }
        .addOnFailureListener { error -> if (continuation.isActive) continuation.resume("OCR_ERROR: ${error.message}"); recognizer.close() }
}
