package com.example.deltalootassistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only catalog and audit history. No network or game-client integration. */
data class LootItem(
    val id: Long = 0,
    val canonicalName: String,
    val aliases: List<String> = emptyList(),
    val referencePrice: Int? = null,
    val weight: Double? = null,
    val rarity: String = "未设置",
    val source: String = "用户录入",
    val updatedAt: Long = System.currentTimeMillis(),
    val manuallyConfirmed: Boolean = false,
    val keepAlways: Boolean = false
)

class LootDatabase(context: Context) : SQLiteOpenHelper(context, "delta_loot.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE loot_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            canonical_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            aliases TEXT NOT NULL DEFAULT '', reference_price INTEGER,
            weight REAL, rarity TEXT NOT NULL DEFAULT '未设置', source TEXT NOT NULL DEFAULT '用户录入',
            updated_at INTEGER NOT NULL, manually_confirmed INTEGER NOT NULL DEFAULT 0,
            keep_always INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, scanned_at INTEGER NOT NULL,
            raw_text TEXT NOT NULL, recognized_name TEXT NOT NULL,
            matched_item_id INTEGER, detected_price INTEGER, decision TEXT NOT NULL,
            manually_edited INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("CREATE INDEX idx_loot_name ON loot_items(canonical_name)")
        db.execSQL("CREATE INDEX idx_history_time ON scan_history(scanned_at DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun upsert(item: LootItem): Long {
        val values = ContentValues().apply {
            put("canonical_name", item.canonicalName.trim())
            put("aliases", item.aliases.joinToString("|"))
            if (item.referencePrice == null) putNull("reference_price") else put("reference_price", item.referencePrice)
            if (item.weight == null) putNull("weight") else put("weight", item.weight)
            put("rarity", item.rarity); put("source", item.source); put("updated_at", System.currentTimeMillis())
            put("manually_confirmed", if (item.manuallyConfirmed) 1 else 0)
            put("keep_always", if (item.keepAlways) 1 else 0)
        }
        val id = writableDatabase.insertWithOnConflict("loot_items", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return if (id > 0) id else readableDatabase.rawQuery(
            "SELECT id FROM loot_items WHERE canonical_name=?", arrayOf(item.canonicalName.trim())
        ).use { if (it.moveToFirst()) it.getLong(0) else -1L }
    }

    fun allItems(): List<LootItem> = readableDatabase.rawQuery(
        "SELECT id,canonical_name,aliases,reference_price,weight,rarity,source,updated_at,manually_confirmed,keep_always FROM loot_items ORDER BY canonical_name COLLATE NOCASE", null
    ).use { c ->
        buildList {
            while (c.moveToNext()) add(LootItem(
                id=c.getLong(0), canonicalName=c.getString(1), aliases=c.getString(2).split('|').filter { it.isNotBlank() },
                referencePrice=if (c.isNull(3)) null else c.getInt(3), weight=if (c.isNull(4)) null else c.getDouble(4),
                rarity=c.getString(5), source=c.getString(6), updatedAt=c.getLong(7), manuallyConfirmed=c.getInt(8)==1, keepAlways=c.getInt(9)==1
            ))
        }
    }

    fun saveHistory(raw: String, name: String, itemId: Long?, price: Int?, decision: String, edited: Boolean) {
        val v = ContentValues().apply {
            put("scanned_at", System.currentTimeMillis()); put("raw_text", raw); put("recognized_name", name)
            if (itemId == null) putNull("matched_item_id") else put("matched_item_id", itemId)
            if (price == null) putNull("detected_price") else put("detected_price", price)
            put("decision", decision); put("manually_edited", if (edited) 1 else 0)
        }
        writableDatabase.insert("scan_history", null, v)
    }

    fun historyCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM scan_history", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
}
