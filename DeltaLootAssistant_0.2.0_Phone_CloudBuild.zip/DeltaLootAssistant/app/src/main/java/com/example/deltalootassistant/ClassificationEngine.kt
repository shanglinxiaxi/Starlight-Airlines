package com.example.deltalootassistant

import java.text.Normalizer
import java.util.Locale

data class LootDetection(
    val rawLine: String,
    val matchedItem: LootItem?,
    val detectedPrice: Int?,
    val priceIsExplicit: Boolean,
    val decision: String,
    val confidenceNote: String
)

object ClassificationEngine {
    private val priceLabel = Regex("(?:价格|单价|价值|售价|估价)\\s*[:：]?\\s*([0-9][0-9,]{0,10})", RegexOption.IGNORE_CASE)

    fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFKC)
        .lowercase(Locale.ROOT).replace(Regex("[\\s·•_—-]"), "")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    fun matchName(line: String, catalog: List<LootItem>): LootItem? {
        val normalizedLine = normalize(line)
        if (normalizedLine.isBlank()) return null
        val candidates = catalog.flatMap { item ->
            (listOf(item.canonicalName) + item.aliases).map { alias -> item to normalize(alias) }
        }.filter { it.second.length >= 2 && normalizedLine.contains(it.second) }
        // Prefer the longest alias to avoid matching a short generic alias first.
        return candidates.maxByOrNull { it.second.length }?.first
    }

    fun parsePrice(line: String): Int? {
        val match = priceLabel.find(normalizePriceSpacing(line)) ?: return null
        return match.groupValues.getOrNull(1)?.replace(",", "")?.toIntOrNull()?.takeIf { it >= 0 }
    }

    fun classify(line: String, catalog: List<LootItem>, threshold: Int): LootDetection {
        val item = matchName(line, catalog)
        val explicitPrice = parsePrice(line)
        val price = explicitPrice ?: item?.referencePrice
        val explicit = explicitPrice != null
        val decision = when {
            item == null -> "未知项 · 待确认"
            item.keepAlways -> "自定义保留 · 保留"
            !item.manuallyConfirmed -> "目录未确认 · 待确认"
            price == null -> "价格缺失 · 待确认"
            explicit && price >= threshold -> "高价值候选 · 保留"
            explicit && price < threshold -> "低价值候选 · 出售复核"
            !explicit -> "参考价候选 · 人工复核"
            else -> "待确认"
        }
        val note = when {
            item == null -> "未匹配到目录名称/别名；不提取普通数字作为价格"
            !explicit && item.referencePrice != null -> "使用目录参考价；截图未出现明确价格标签"
            !explicit -> "未发现明确价格字段"
            else -> "价格来自明确的价格/单价/价值/售价/估价标签"
        }
        return LootDetection(line, item, price, explicit, decision, note)
    }

    private fun normalizePriceSpacing(line: String): String = line.replace(Regex("\\s+"), " ")
}
