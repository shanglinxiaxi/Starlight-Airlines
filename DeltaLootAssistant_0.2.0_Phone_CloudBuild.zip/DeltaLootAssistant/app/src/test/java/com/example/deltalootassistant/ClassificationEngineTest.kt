package com.example.deltalootassistant

import org.junit.Assert.*
import org.junit.Test

class ClassificationEngineTest {
    private val confirmed = LootItem(
        id=1, canonicalName="高级电路板", aliases=listOf("电路板", "PCB"),
        referencePrice=42000, weight=0.2, rarity="稀有", source="人工核验", manuallyConfirmed=true
    )

    @Test fun matchesCanonicalNameAndAliasIgnoringSpacing() {
        assertEquals(confirmed, ClassificationEngine.matchName("高级 电路板", listOf(confirmed)))
        assertEquals(confirmed, ClassificationEngine.matchName("拾取：PCB", listOf(confirmed)))
    }

    @Test fun doesNotTreatUnlabelledDigitsAsPrice() {
        assertNull(ClassificationEngine.parsePrice("高级电路板 x2 编号 123456"))
        val result = ClassificationEngine.classify("高级电路板 x2 编号 123456", listOf(confirmed), 50000)
        assertEquals("参考价候选 · 人工复核", result.decision)
        assertFalse(result.priceIsExplicit)
    }

    @Test fun acceptsExplicitPriceLabelOnly() {
        assertEquals(123456, ClassificationEngine.parsePrice("高级电路板 价格：123,456"))
        val result = ClassificationEngine.classify("高级电路板 价格：123456", listOf(confirmed), 50000)
        assertEquals("高价值候选 · 保留", result.decision)
        assertTrue(result.priceIsExplicit)
    }

    @Test fun unknownItemsStayPendingEvenWhenNumbersAreLarge() {
        val result = ClassificationEngine.classify("未知物品 编号 999999", listOf(confirmed), 50000)
        assertNull(result.matchedItem)
        assertEquals("未知项 · 待确认", result.decision)
        assertNull(result.detectedPrice)
    }

    @Test fun customKeepListOverridesPriceThreshold() {
        val keep = confirmed.copy(keepAlways=true)
        val result = ClassificationEngine.classify("高级电路板 价格：100", listOf(keep), 50000)
        assertEquals("自定义保留 · 保留", result.decision)
    }
}
